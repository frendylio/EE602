# 3_1_Output

Output for Question 3.1 of report

# How to test
Please create a folder called "resources" where all the puzzle.txt are saved.

Then choose the type of testing you want to see.
